#!/bin/bash

python main_fed.py --dataset fashion_mnist --model cnn --attack lp_attack --lr 0.01 --malicious 0.3 --poison_frac 1.0 --local_ep 2 --local_bs 64 --attack_begin 0 --defence MyDefense  --epochs 200 --attack_label 5 --attack_goal -1 --trigger 'square' --triggerX 23 --triggerY 23 --gpu 0 --iid 0 --save save/quick_start

#python main_fed.py --dataset cifar --model VGG --attack lp_attack --lr 0.1 --malicious 0.3 --poison_frac 1.0 --local_ep 2 --local_bs 64 --attack_begin 0 --defence MyDefense  --epochs 200 --attack_label 5 --attack_goal -1 --trigger 'square' --triggerX 27 --triggerY 27 --gpu 0 --iid 0 --save save/quick_start

#python main_fed.py --dataset cifar --model resnet --attack lp_attack --lr 0.1 --malicious 0.3 --poison_frac 1.0 --local_ep 2 --local_bs 64 --attack_begin 0 --defence MyDefense  --epochs 200 --attack_label 5 --attack_goal -1 --trigger 'square' --triggerX 27 --triggerY 27 --gpu 0 --iid 0 --save save/quick_start