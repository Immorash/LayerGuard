Ⅰ、Base Environment：
	OS：Ubuntu 22.04
	Python：3.12
	PyTorch：2.5.1
	CUDA：12.4
	NumPy：2.1.3

Ⅱ、 Additional Python dependencies are listed in the requirement.sh script. You can install them by executing the script as follows:
	1、cd LayerGuard-source
	2、./requirement.sh

Ⅲ、① For Untargeted Attack
	To run LayerGuard against untargeted attacks, execute the following steps:
		1、cd LayerGuard-source/LayerGuard-UntargetedAttack
		2、bash ./scripts/cifar10/baselines.sh
	
	② For LP Attack
	To run LayerGuard against the LP attack, execute the following steps:
		1、cd LayerGuard-source/LayerGuard-LPAttack
		2、./run.sh

