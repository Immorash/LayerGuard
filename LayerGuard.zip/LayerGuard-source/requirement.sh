#!/bin/bash
pip install scikit-image

pip install opencv-python

pip install scikit-learn

pip install hdbscan